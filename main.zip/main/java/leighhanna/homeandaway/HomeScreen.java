package leighhanna.homeandaway;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class HomeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        setTitle("Home and away app");

    }

    public void  btnWorkoutSelectionOnClick(View v)
    {
        Intent activityWorkoutSelect = new Intent(this, WorkoutSelect.class);
        startActivity(activityWorkoutSelect);
    }

    public void  btnStepOnClick(View v)
    {
        Intent activityNews = new Intent(this, StepCount.class);
        startActivity(activityNews);
    }

    public void  btnNewsOnClick(View v)
    {
        Intent activityNews = new Intent(this, News.class);
        startActivity(activityNews);
    }

    public void  btnBarbellProgressOnClick(View v)
    {
        Intent activityBarbellProgress = new Intent(this, Progress.class);
        startActivity(activityBarbellProgress);
    }

    public void  btnTestOnClick(View v)
    {
        Intent activityTest = new Intent(this, CustomSelection.class);
        startActivity(activityTest);
    }

}
