package leighhanna.homeandaway;

import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import java.util.Date;
import java.util.List;

public class WorkoutSelect extends AppCompatActivity {
    double RepWeight5;
    double RepWeight4;
    double RepWeight3;


    SwipeRefreshLayout mSwipeLayout;
    TableLayout workoutTable;

    EditText numWarmUpWeight;
    TextView tvWarmUpSet5Rep;
    TextView tvWarmUpSet4Rep;
    TextView tvWarmUpSet3Rep;

    //SECOND SEGMENT
    ArrayList<String> arrayList = new ArrayList<String>();
    ArrayList<String> arrayListMN = new ArrayList<String>();
    ArrayList<String> workoutArray = new ArrayList<String>();

    DatabaseHelperWorkout databaseHelper;

    TextView tvTip;
    TextView[] tvWExercise = new TextView[9];
    TextView[] tvWReps = new TextView[9];
    TextView[] tvWSets = new TextView[9];
    TextView tvcount;
    Button button;
    int seconds = 0;
    CountDownTimer countDown;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_select);
        setTitle("Workout Select");
        databaseHelper = new DatabaseHelperWorkout(this);
        viewTextSetup();

        workoutTable = (TableLayout) findViewById(R.id.workoutTable);

        tvTip = (TextView) findViewById(R.id.tvTip);
        numWarmUpWeight = (EditText) findViewById(R.id.numWarmUpWeight);
        tvWarmUpSet5Rep = (TextView) findViewById(R.id.tvWarmUpSet5Rep);
        tvWarmUpSet4Rep = (TextView) findViewById(R.id.tvWarmUpSet4Rep);
        tvWarmUpSet3Rep = (TextView) findViewById(R.id.tvWarmUpSet3Rep);

        tvcount = (TextView) findViewById(R.id.tvcount);


        List<String> arraySpinner = databaseHelper.getWorkoutNames();
        if(arraySpinner.isEmpty())
        {
            databaseHelper.makeBasicWorkout();
            arraySpinner = databaseHelper.getWorkoutNames();
        }

        final Spinner s = (Spinner) findViewById(R.id.WorkoutSpinner);

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, arraySpinner);
        s.setAdapter(adapter);
        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedItemText = (String) s.getItemAtPosition(position);
                // Notify the selected item text
                Toast.makeText
                        (getApplicationContext(), "Selected : " + selectedItemText, Toast.LENGTH_SHORT)
                        .show();
                changeWorkout(selectedItemText);
                String secondString = databaseHelper.getRest(selectedItemText);
                seconds = Integer.valueOf(secondString);
                try {
                    countDown.cancel();
                    tvcount.setText("N/A - TIMER");

                }
                catch (Exception e)
                {

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }

        });

        numWarmUpWeight.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                try {
                    RepWeight5 = Double.parseDouble(numWarmUpWeight.getText().toString());
                    RepWeight4 = Double.parseDouble(numWarmUpWeight.getText().toString());
                    RepWeight3 = Double.parseDouble(numWarmUpWeight.getText().toString());

                    RepWeight5 = (RepWeight5/100)*25;
                    RepWeight4 = (RepWeight4/100)*50;
                    RepWeight3 = (RepWeight3/100)*75;

                }
                catch(Exception e)
                {

                }
                if(s.length() != 0)
                    try {
                        tvWarmUpSet5Rep.setText(String.format("%.2f",RepWeight5));
                        tvWarmUpSet4Rep.setText(String.format("%.2f",RepWeight4));
                        tvWarmUpSet3Rep.setText(String.format("%.2f",RepWeight3));
                    }
                    catch(Exception e)
                    {

                    }
            }
        });

        final TextView tvcount = (TextView) findViewById( R.id.tvcount );
        button = (Button) findViewById(R.id.btncount);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                try {
                    countDown.cancel();
                    tvcount.setText("");
                }
                catch (Exception e)
                {

                }
                //+50 to account for delay caused be cancel, this was found through testing
                countDown = new CountDownTimer((seconds* 1000) + 50, 1000){
                    public void onTick(long millisUntilFinished){
                        tvcount.setText(String.valueOf((millisUntilFinished/1000)));

                    }
                    public  void onFinish(){
                        tvcount.setText("FINISH!!");
                        ToneGenerator toneG = new ToneGenerator(AudioManager.STREAM_ALARM, 50);
                        toneG.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 800);

                    }
                }.start();
            }
        });


    }


    public void changeWorkout(String s)
    {
        viewTextSetup();
        workoutArray = databaseHelper.getWorkoutNumber(s);
        TextSetup(workoutArray.get(0));
    }



    public void TextSetup(String workout)
    {
        String tiphold = "";
        arrayList = databaseHelper.getWorkout("1");
        if(arrayList.size() == 0)
        {
            databaseHelper.makeBasicWorkout();
            arrayList = databaseHelper.getWorkout(workout);
        }
        arrayList = databaseHelper.getWorkout(workout);
        int row = 1;
        for (int i = 0; i < arrayList.size(); i++){
            arrayListMN = databaseHelper.getMovementName(arrayList.get(i));
            tvWExercise[row].setText(arrayListMN.get(0));
            i++;
            tvWReps[row].setText(arrayList.get(i));
            i++;
            tvWSets[row].setText(arrayList.get(i));
            row++;

        }
        tiphold = databaseHelper.getTip(workout);
        tvTip.setText(tiphold);

    }

    public void viewTextSetup()
    {
        tvWExercise[0] = (TextView) findViewById(R.id.tvWExercise0);
        tvWExercise[1] = (TextView) findViewById(R.id.tvWExercise1);
        tvWExercise[2] = (TextView) findViewById(R.id.tvWExercise2);
        tvWExercise[3] = (TextView) findViewById(R.id.tvWExercise3);
        tvWExercise[4] = (TextView) findViewById(R.id.tvWExercise4);
        tvWExercise[5] = (TextView) findViewById(R.id.tvWExercise5);
        tvWExercise[6] = (TextView) findViewById(R.id.tvWExercise6);
        tvWExercise[7] = (TextView) findViewById(R.id.tvWExercise7);
        tvWExercise[8] = (TextView) findViewById(R.id.tvWExercise8);
        for(int i=1; i < 8; i++)
        {
            tvWExercise[i].setText("");
        }

        tvWReps[0] = (TextView) findViewById(R.id.tvWReps0);
        tvWReps[1] = (TextView) findViewById(R.id.tvWReps1);
        tvWReps[2] = (TextView) findViewById(R.id.tvWReps2);
        tvWReps[3] = (TextView) findViewById(R.id.tvWReps3);
        tvWReps[4] = (TextView) findViewById(R.id.tvWReps4);
        tvWReps[5] = (TextView) findViewById(R.id.tvWReps5);
        tvWReps[6] = (TextView) findViewById(R.id.tvWReps6);
        tvWReps[7] = (TextView) findViewById(R.id.tvWReps7);
        tvWReps[8] = (TextView) findViewById(R.id.tvWReps8);
        for(int i=1; i < 8; i++)
        {
            tvWReps[i].setText("");
        }

        tvWSets[0] = (TextView) findViewById(R.id.tvWSets0);
        tvWSets[1] = (TextView) findViewById(R.id.tvWSets1);
        tvWSets[2] = (TextView) findViewById(R.id.tvWSets2);
        tvWSets[3] = (TextView) findViewById(R.id.tvWSets3);
        tvWSets[4] = (TextView) findViewById(R.id.tvWSets4);
        tvWSets[5] = (TextView) findViewById(R.id.tvWSets5);
        tvWSets[6] = (TextView) findViewById(R.id.tvWSets6);
        tvWSets[7] = (TextView) findViewById(R.id.tvWSets7);
        tvWSets[8] = (TextView) findViewById(R.id.tvWSets8);

        for(int i=1; i < 8; i++)
        {
            tvWSets[i].setText("");
        }

    }

}