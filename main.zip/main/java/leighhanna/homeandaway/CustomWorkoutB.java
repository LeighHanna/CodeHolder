package leighhanna.homeandaway;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class CustomWorkoutB extends AppCompatActivity {
    DatabaseHelperWorkout databaseHelper;

    Spinner[] spExercise = new Spinner[8];
    EditText[] repSelect = new EditText[8];
    EditText[] setSelect = new EditText[8];
    EditText rest;
    EditText tip;

    ArrayAdapter<String>[] adapter = new ArrayAdapter[8];
    List<String>[] arraySpinner = new List[8];
    String repHold;
    String setHold;
    String currentWorkoutName = "Custom_B_Day";
    String currentWorkout = "8";
    int workoutNumber = 32;
    int current;
    Boolean mySetup = false;

    ArrayList<String> arrayList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_workout);
        setTitle("Custom Day B");

        databaseHelper = new DatabaseHelperWorkout(this);
        dataHolderSetup();

        List<String> arraySpinner = databaseHelper.getWorkoutNames();
        if(arraySpinner.isEmpty())
        { databaseHelper.makeBasicWorkout();
           arraySpinner = databaseHelper.getWorkoutNames();
        }

        populateHolder();
    }

    public void dataHolderSetup()
    {
        rest = (EditText) findViewById(R.id.restSelect);
        tip = (EditText) findViewById(R.id.tipSelect);

        spExercise[0] = (Spinner) findViewById(R.id.spExercise0);
        spExercise[1] = (Spinner) findViewById(R.id.spExercise1);
        spExercise[2] = (Spinner) findViewById(R.id.spExercise2);
        spExercise[3] = (Spinner) findViewById(R.id.spExercise3);
        spExercise[4] = (Spinner) findViewById(R.id.spExercise4);
        spExercise[5] = (Spinner) findViewById(R.id.spExercise5);
        spExercise[6] = (Spinner) findViewById(R.id.spExercise6);
        spExercise[7] = (Spinner) findViewById(R.id.spExercise7);


        repSelect[0] = (EditText) findViewById(R.id.repSelect0);
        repSelect[1] = (EditText) findViewById(R.id.repSelect1);
        repSelect[2] = (EditText) findViewById(R.id.repSelect2);
        repSelect[3] = (EditText) findViewById(R.id.repSelect3);
        repSelect[4] = (EditText) findViewById(R.id.repSelect4);
        repSelect[5] = (EditText) findViewById(R.id.repSelect5);
        repSelect[6] = (EditText) findViewById(R.id.repSelect6);
        repSelect[7] = (EditText) findViewById(R.id.repSelect7);

        setSelect[0] = (EditText) findViewById(R.id.setSelect0);
        setSelect[1] = (EditText) findViewById(R.id.setSelect1);
        setSelect[2] = (EditText) findViewById(R.id.setSelect2);
        setSelect[3] = (EditText) findViewById(R.id.setSelect3);
        setSelect[4] = (EditText) findViewById(R.id.setSelect4);
        setSelect[5] = (EditText) findViewById(R.id.setSelect5);
        setSelect[6] = (EditText) findViewById(R.id.setSelect6);
        setSelect[7] = (EditText) findViewById(R.id.setSelect7);

    }

    public void populateHolder()
    {
        arrayList = databaseHelper.getWorkout(currentWorkout);

        for(int i=0; i < 8; i++)
        {
            arraySpinner[i] = databaseHelper.getMovementNames();
            if (arraySpinner[i].isEmpty()) {
                databaseHelper.makeBasicWorkout();
                arraySpinner[i] = databaseHelper.getMovementNames();
            }

            adapter[i] = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_dropdown_item, arraySpinner[i]);
            spExercise[i].setAdapter(adapter[i]);
            int place = (i*3);

            spExercise[i].setSelection(Integer.valueOf(arrayList.get(place))-1);



        }

        for(int i=0; i < 8; i++)
        {
            int place = workoutNumber + i;
            repHold = databaseHelper.getRep(Integer.toString(place));
            repSelect[i].setText(repHold);
        }

        for(int i=0; i < 8; i++)
        {
            int place = workoutNumber + i;
            setHold = databaseHelper.getSet(Integer.toString(place));
            setSelect[i].setText(setHold);
        }

        rest.setText(databaseHelper.getRest(currentWorkoutName));
        tip.setText(databaseHelper.getTip(currentWorkout));

        if(mySetup == false) {
            mySetup = true;
            onChangePopulation();
        }
    }

    public void onChangePopulation()
    {
        for(int i=0; i < 8; i++) {
            current = i;
            arraySpinner[i] = databaseHelper.getMovementNames();
            if (arraySpinner[i].isEmpty()) {
                databaseHelper.makeBasicWorkout();
                arraySpinner[i] = databaseHelper.getMovementNames();
            }

            spExercise[i].setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                    String selectedItemText = (String) spExercise[current].getItemAtPosition(position);
                    // Notify the selected item text
                    saveWorkout();


                }

                @Override
                public void onNothingSelected(AdapterView<?> parentView) {

                }

            });
        }

        //repselect
        for(int i=0; i < 8; i++)
        {
            repSelect[i].addTextChangedListener(new TextWatcher() {

                @Override
                public void afterTextChanged(Editable s) {}

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    saveWorkout();
                }
            });
        }

        //setSelect
        for(int i=0; i < 8; i++)
        {
            setSelect[i].addTextChangedListener(new TextWatcher() {

                @Override
                public void afterTextChanged(Editable s) {}

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    saveWorkout();
                }
            });
        }

        rest.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                saveWorkout();
            }
        });

        tip.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                saveWorkout();
            }
        });

    }



    public void saveWorkout()
    {

        for(int i=0; i < 8; i++)
        {
            databaseHelper.updateExercise(
                    String.valueOf(i+workoutNumber),
                    currentWorkout,
                    databaseHelper.getMovementNumber(spExercise[i].getSelectedItem().toString()),
                    repSelect[i].getText().toString(),
                    setSelect[i].getText().toString()
            );

        }

        databaseHelper.updateWorkout(
                currentWorkout,
                currentWorkoutName,
                rest.getText().toString());

        databaseHelper.updateTip(
                currentWorkout,
                tip.getText().toString());


    }


}
