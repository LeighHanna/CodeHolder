package leighhanna.homeandaway;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;


public class DatabaseHelperWorkout extends SQLiteOpenHelper {
    public static String DATABASE_NAME = "Workout_database";
    private static final int DATABASE_VERSION = 1;

    //TIP
    private static final String TABLE_TIP = "Tip";
    private static final String KEY_TIPID = "tipId";
    private static final String KEY_TIP = "tip";
    //WORKOUT
    private static final String TABLE_WORKOUT = "Workout";
    private static final String KEY_WORKOUTID = "workoutId";
    private static final String KEY_WORKOUTNAME = "workoutName";
    private static final String KEY_WORKOUT_TIPID = "tipId";
    private static final String KEY_REST = "rest";
    //MOVEMENT
    private static final String TABLE_MOVEMENT = "Movement";
    private static final String KEY_MOVEMENTID = "movementId";
    private static final String KEY_MOVEMENTNAME = "movementName";
    //EXERCISE
    private static final String TABLE_EXERCISE = "Exercise";
    private static final String KEY_EXERCISEID = "exerciseId";
    private static final String KEY_EXERCISE_WORKOUTID = "workoutId";
    private static final String KEY_EXERCISE_MOVEMENTID = "movementId";
    private static final String KEY_SETS = "sets";
    private static final String KEY_REPS = "reps";




    //CREATE TABLES
    private static final String CREATE_TABLE_TIP = "CREATE TABLE "
            + TABLE_TIP + "(" + KEY_TIPID
            + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_TIP + " TEXT);";

    private static final String CREATE_TABLE_WORKOUT = "CREATE TABLE "
            + TABLE_WORKOUT + "(" + KEY_WORKOUTID
            + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_WORKOUTNAME + " TEXT ," + KEY_WORKOUT_TIPID + " INTEGER," + KEY_REST + " TEXT);";

    private static final String CREATE_TABLE_MOVEMENT = "CREATE TABLE "
            + TABLE_MOVEMENT + "(" + KEY_MOVEMENTID + " INTEGER PRIMARY KEY AUTOINCREMENT,"+ KEY_MOVEMENTNAME + " TEXT);";

    private static final String CREATE_TABLE_EXERCISE = "CREATE TABLE "
            + TABLE_EXERCISE + "(" + KEY_EXERCISEID + " INTEGER," + KEY_EXERCISE_WORKOUTID + " INTEGER," + KEY_EXERCISE_MOVEMENTID + " INTEGER,"+ KEY_REPS + " TEXT,"+ KEY_SETS + " TEXT);";

    public DatabaseHelperWorkout(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

        Log.d("table", CREATE_TABLE_TIP);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_TIP);
        db.execSQL(CREATE_TABLE_WORKOUT);
        db.execSQL(CREATE_TABLE_MOVEMENT);
        db.execSQL(CREATE_TABLE_EXERCISE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_TIP + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_WORKOUT + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_MOVEMENT + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_EXERCISE + "'");
        onCreate(db);
    }

    //ADD METHODS
    public void addTip(String tip) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TIP, tip);
        db.insertWithOnConflict(TABLE_TIP, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void addWorkout(String name, String tipId, String restSec) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_WORKOUTNAME, name);
        values.put(KEY_TIPID, tipId);
        values.put(KEY_REST, restSec);

        db.insertWithOnConflict(TABLE_WORKOUT, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void addMovement(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_MOVEMENTNAME, name);

        db.insertWithOnConflict(TABLE_MOVEMENT, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void addExercise(String eID, String wID, String mID, String reps, String sets) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_EXERCISEID, eID);
        values.put(KEY_EXERCISE_WORKOUTID, wID);
        values.put(KEY_EXERCISE_MOVEMENTID, mID);
        values.put(KEY_REPS, reps);
        values.put(KEY_SETS, sets);

        db.insertWithOnConflict(TABLE_EXERCISE, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    //GET METHODS
    public String getTip(String which) {
        String tipID = "";
        String tip = "";

        String selectQuery = "SELECT tipId FROM " + TABLE_WORKOUT + " WHERE workoutId = '" + which + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            do {
                tipID = c.getString(c.getColumnIndex(KEY_WORKOUT_TIPID));
            } while (c.moveToNext());
        }
        String selectQuery2 = "SELECT tip FROM " + TABLE_TIP + " WHERE tipId = '" + tipID + "'";
        Cursor c2 = db.rawQuery(selectQuery2, null);

        if (c2.moveToFirst()) {
            do {
                tip = c2.getString(c2.getColumnIndex(KEY_TIP));
            } while (c2.moveToNext());
        }
        return tip;
    }
    public String getRest(String which) {
        String rest = "";
        String selectQuery = "SELECT rest FROM " + TABLE_WORKOUT + " WHERE workoutName = '" + which + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            do {
                rest = c.getString(c.getColumnIndex(KEY_REST));
            } while (c.moveToNext());
        }
        return rest;
    }

    public ArrayList<String> getWorkout(String which) {
        ArrayList<String> studentsArrayList = new ArrayList<String>();
        String movement="";
        String sets="";
        String reps="";

        String selectQueryE = "SELECT  * FROM " + TABLE_EXERCISE + " WHERE workoutId = '"+ which +"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cE = db.rawQuery(selectQueryE, null);

        if (cE.moveToFirst()) {
            do {
                movement = cE.getString(cE.getColumnIndex(KEY_EXERCISE_MOVEMENTID));
                reps = cE.getString(cE.getColumnIndex(KEY_REPS));
                sets = cE.getString(cE.getColumnIndex(KEY_SETS));

                studentsArrayList.add(movement);
                studentsArrayList.add(reps);
                studentsArrayList.add(sets);
            } while (cE.moveToNext());
            Log.d("array", studentsArrayList.toString());
        }

        return studentsArrayList;
    }
    public ArrayList<String> getMovementName(String which)
    {
        ArrayList<String> studentsArrayList = new ArrayList<String>();
        String movement="";

        String selectQueryE = "SELECT  * FROM " + TABLE_MOVEMENT + " WHERE movementId = '"+ which +"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cE = db.rawQuery(selectQueryE, null);

        if (cE.moveToFirst()) {
            do {
                movement = cE.getString(cE.getColumnIndex(KEY_MOVEMENTNAME));

                studentsArrayList.add(movement);
            } while (cE.moveToNext());
            Log.d("array", studentsArrayList.toString());
        }

        return studentsArrayList;
    }

    public ArrayList<String> getWorkoutNames() {
        ArrayList<String> studentsArrayList = new ArrayList<String>();
        String workout="";
        String selectQuery = "SELECT  * FROM " + TABLE_WORKOUT;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                workout = c.getString(c.getColumnIndex(KEY_WORKOUTNAME));

                studentsArrayList.add(workout);
            } while (c.moveToNext());
            Log.d("array", studentsArrayList.toString());
        }
        return studentsArrayList;
    }

    public ArrayList<String> getMovementNames() {
        ArrayList<String> studentsArrayList = new ArrayList<String>();
        String movement="";
        String selectQuery = "SELECT  * FROM " + TABLE_MOVEMENT;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                movement = c.getString(c.getColumnIndex(KEY_MOVEMENTNAME));

                studentsArrayList.add(movement);
            } while (c.moveToNext());
            Log.d("array", studentsArrayList.toString());
        }
        return studentsArrayList;
    }

    public ArrayList<String> getWorkoutNumber(String which) {
        ArrayList<String> studentsArrayList = new ArrayList<String>();
        String workoutID="";
        String selectQuery = "SELECT  * FROM " + TABLE_WORKOUT + " WHERE workoutName = '"+ which +"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                workoutID = c.getString(c.getColumnIndex(KEY_WORKOUTID));

                studentsArrayList.add(workoutID);
            } while (c.moveToNext());
            Log.d("array", studentsArrayList.toString());
        }
        return studentsArrayList;
    }

    public String getRep(String which)
    {
        String reps = "";
        String selectQuery = "SELECT reps FROM " + TABLE_EXERCISE + " WHERE exerciseId = '" + which + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            do {
                reps = c.getString(c.getColumnIndex(KEY_REPS));
            } while (c.moveToNext());
        }
        return reps;
    }

    public String getSet(String which)
    {
        String Sets = "";
        String selectQuery = "SELECT sets FROM " + TABLE_EXERCISE + " WHERE exerciseId = '" + which + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            do {
                Sets = c.getString(c.getColumnIndex(KEY_SETS));
            } while (c.moveToNext());
        }
        return Sets;
    }

    public String getMovementNumber(String which)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String number = "";
        String selectQuery = "SELECT movementId FROM " + TABLE_MOVEMENT + " WHERE movementName = '"+ which +"'";
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                number = c.getString(c.getColumnIndex(KEY_MOVEMENTID));

            } while (c.moveToNext());

        }
        return number;
    }

    //UPDATE METHODS
    public void updateExercise(String eID, String wID, String mID, String reps, String sets) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_EXERCISE_WORKOUTID, wID);
        values.put(KEY_EXERCISE_MOVEMENTID, mID);
        values.put(KEY_REPS, reps);
        values.put(KEY_SETS, sets);

        db.update(TABLE_EXERCISE, values, KEY_EXERCISEID + " = ?", new String[]{String.valueOf(eID)});
    }

    public void updateWorkout(String wID ,String name, String restSec) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_WORKOUTNAME, name);
        values.put(KEY_REST, restSec);

        db.update(TABLE_WORKOUT, values, KEY_WORKOUTID + " = ?", new String[]{String.valueOf(wID)});
    }

    public void updateTip(String tID ,String tip) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TIP, tip);

        db.update(TABLE_TIP, values, KEY_TIPID + " = ?", new String[]{String.valueOf(tID)});
    }

    //MAKE BASIC WORKOUT
    public void makeBasicWorkout()
    {

        addTip("Note:This is a cluster set program, set another timer for 7 min 15 seconds(each exercise) and get as many sets as possible, rest provided is only a minimum, NEVER FAIL A REP if you think you wont make the rep don't attempt it");//Tip1 - blank tip
        addTip("Note:");
        addTip("Note:");
        addTip("Note:");
        addTip("Note:");
        addTip("Note:First week do 8 reps next week add 1 rep, keep doing this each week until 12 total reps");
        addTip("Note:");
        addTip("Note:");
        addTip("Note:");
        addTip("Note:");
        addTip("Note:");


        addWorkout("HomeAndAwayBasic","1","15"); //id 1
        addWorkout("StrongLifts5x5_A_Day","2","180"); //id 2
        addWorkout("StrongLifts5x5_B_Day","3","180");//id 3
        addWorkout("StartingStrength_A_Day","4","180");//id 4
        addWorkout("StartingStrength_B_Day","5","180");//id 5
        addWorkout("Allpro","6","90");//id 6
        addWorkout("Custom_A_Day","7","180");//id 7
        addWorkout("Custom_B_Day","8","180");//id 8
        addWorkout("Custom_C_Day","9","180");//id 9
        addWorkout("Custom_D_Day","10","180");//id 10
        addWorkout("Custom_E_Day","11","180");//id 11

        addMovement("N/A"); //id 1
        addMovement("BenchPress"); //id 2
        addMovement("Squat");//id 3
        addMovement("Row");//id 4
        addMovement("Deadlift");//id 5
        addMovement("Press");//id 6
        addMovement("Curl");//id 7
        addMovement("Calfraise");//id 8
        addMovement("Pullup");//id 9
        addMovement("SL-Deadlift");//id 10

        //HomeAndAwayBasic
        addExercise("1","1","2","Pick your own","as many as possible");
        addExercise("2","1","4","Same as above","as many as possible");
        addExercise("3","1","3","Same as above","as many as possible");
        addExercise("4","1","6","Same as above","as many as possible");

        //StrongLifts5x5_A_Day
        addExercise("5","2","3","5","5");
        addExercise("6","2","2","5","5");
        addExercise("7","2","4","5","5");

        //StrongLifts5x5_B_Day
        addExercise("8","3","3","5","5");
        addExercise("9","3","6","5","5");
        addExercise("10","3","5","5","1");

        //StartingStrength_A_Day
        addExercise("11","4","3","5","3");
        addExercise("12","4","2","5","3");
        addExercise("13","4","5","5","1");

        //StartingStrength_B_Day
        addExercise("14","5","3","5","3");
        addExercise("15","5","6","5","3");
        addExercise("16","5","4","5","3");

        //Allpro
        addExercise("17","6","3","8-12","2");
        addExercise("18","6","2","8-12","2");
        addExercise("19","6","4","8-12","2");
        addExercise("20","6","6","8-12","2");
        addExercise("21","6","10","8-12","2");
        addExercise("22","6","7","8-12","2");
        addExercise("23","6","8","8-12","2");

        //custom A Day
        addExercise("24","7","1","0","0");
        addExercise("25","7","1","0","0");
        addExercise("26","7","1","0","0");
        addExercise("27","7","1","0","0");
        addExercise("28","7","1","0","0");
        addExercise("29","7","1","0","0");
        addExercise("30","7","1","0","0");
        addExercise("31","7","1","0","0");

        //custom B Day
        addExercise("32","8","1","0","0");
        addExercise("33","8","1","0","0");
        addExercise("34","8","1","0","0");
        addExercise("35","8","1","0","0");
        addExercise("36","8","1","0","0");
        addExercise("37","8","1","0","0");
        addExercise("38","8","1","0","0");
        addExercise("39","8","1","0","0");

        //custom C Day
        addExercise("40","9","1","0","0");
        addExercise("41","9","1","0","0");
        addExercise("42","9","1","0","0");
        addExercise("43","9","1","0","0");
        addExercise("44","9","1","0","0");
        addExercise("45","9","1","0","0");
        addExercise("46","9","1","0","0");
        addExercise("47","9","1","0","0");

        //custom D Day
        addExercise("48","10","1","0","0");
        addExercise("49","10","1","0","0");
        addExercise("50","10","1","0","0");
        addExercise("51","10","1","0","0");
        addExercise("52","10","1","0","0");
        addExercise("53","10","1","0","0");
        addExercise("54","10","1","0","0");
        addExercise("55","10","1","0","0");

        //custom E Day
        addExercise("56","11","1","0","0");
        addExercise("57","11","1","0","0");
        addExercise("58","11","1","0","0");
        addExercise("59","11","1","0","0");
        addExercise("60","11","1","0","0");
        addExercise("61","11","1","0","0");
        addExercise("62","11","1","0","0");
        addExercise("63","11","1","0","0");
    }

}