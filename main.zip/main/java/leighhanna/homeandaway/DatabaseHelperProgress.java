package leighhanna.homeandaway;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;

public class DatabaseHelperProgress extends SQLiteOpenHelper {
    public static String DATABASE_NAME = "Progress_database";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_PROGRESS = "Progress";
    private static final String KEY_ID = "id";
    private static final String KEY_MOVEMENT = "movement";
    private static final String KEY_REPS = "reps";
    private static final String KEY_WEIGHT = "weight";


    private static final String CREATE_TABLE_USER = "CREATE TABLE "
            + TABLE_PROGRESS + "(" + KEY_ID
            + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_MOVEMENT + " TEXT," + KEY_REPS + " TEXT," + KEY_WEIGHT + " TEXT );";
    public DatabaseHelperProgress(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("table", CREATE_TABLE_USER);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USER);

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_PROGRESS + "'");
        onCreate(db);
    }
    public long addPrgressDetail(String movement,String reps, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_MOVEMENT, movement);
        values.put(KEY_REPS, reps);
        values.put(KEY_WEIGHT, weight);

        long insert = db.insert(TABLE_PROGRESS, null, values);
        return insert;
    }
    public ArrayList<String> getAllProgressList() {
        ArrayList<String> studentsArrayList = new ArrayList<String>();
        String movement="";
        String reps="";
        String weight="";
        String selectQuery = "SELECT  * FROM " + TABLE_PROGRESS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                movement = c.getString(c.getColumnIndex(KEY_MOVEMENT));
                reps = c.getString(c.getColumnIndex(KEY_REPS));
                weight = c.getString(c.getColumnIndex(KEY_WEIGHT));

                studentsArrayList.add(movement);
                studentsArrayList.add(reps);
                studentsArrayList.add(weight);
            } while (c.moveToNext());
            Log.d("array", studentsArrayList.toString());
        }
        return studentsArrayList;
    }

    public void updateUser(String movement, String reps, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_REPS, reps);
        values.put(KEY_WEIGHT, weight);
        db.update(TABLE_PROGRESS, values, KEY_MOVEMENT + " = ?", new String[]{String.valueOf(movement)});
    }

    public ArrayList<String> getSpecificProgressList(String which) {
        ArrayList<String> progressArrayList = new ArrayList<String>();
        String reps="";
        String weight="";
        String selectQuery = "SELECT  * FROM " + TABLE_PROGRESS + " WHERE movement ='"+ which +"'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                reps = c.getString(c.getColumnIndex(KEY_REPS));
                weight = c.getString(c.getColumnIndex(KEY_WEIGHT));

                progressArrayList.add(reps);
                progressArrayList.add(weight);
            } while (c.moveToNext());
            Log.d("array", progressArrayList.toString());
        }
        return progressArrayList;
    }

}