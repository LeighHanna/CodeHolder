package leighhanna.homeandaway;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Progress extends AppCompatActivity {

    TextView[] tvMovement = new TextView[10];
    TextView[] tvRep = new TextView[10];
    TextView[] tvWeight = new TextView[10];
    DatabaseHelperProgress databaseHelper;
    ArrayList<String> arrayList;
    List<String> arraySpinner = new ArrayList<String>();
    Spinner spinner;

    private Button btnIncreaseWeight, btnDecreaseWeight, btnIncreaseReps, btnDecreaseReps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);
        setTitle("Progress");
        databaseHelper = new DatabaseHelperProgress(this);
        viewTextSetup();
        TextSetup();
        setSpinner();

        btnIncreaseWeight = (Button) findViewById(R.id.btnWeightUp);
        btnDecreaseWeight = (Button) findViewById(R.id.btnWeightDown);
        btnIncreaseReps = (Button) findViewById(R.id.btnRepsUp);
        btnDecreaseReps = (Button) findViewById(R.id.btnRepsDown);

        btnIncreaseWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseWeight();
                //Toast.makeText(Progress.this, "Weight Increased by 0.5KG!", Toast.LENGTH_SHORT).show();
            }
        });

        btnDecreaseWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseWeight();
                //Toast.makeText(Progress.this, "Weight Decreased by 0.5KG!", Toast.LENGTH_SHORT).show();
            }
        });

        btnIncreaseReps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseReps();
                //Toast.makeText(Progress.this, "Reps Increased by 1REP!", Toast.LENGTH_SHORT).show();
            }
        });

        btnDecreaseReps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseReps();
                //Toast.makeText(Progress.this, "Reps Decreased by 1REP!", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void makeBasicProgress(){
        databaseHelper.addPrgressDetail("Movement","Reps","Weight");
        databaseHelper.addPrgressDetail("Bench Press","8","20");
        databaseHelper.addPrgressDetail("Squat","8","20");
        databaseHelper.addPrgressDetail("Row","8","20");
        databaseHelper.addPrgressDetail("Deadlift","8","20");
        databaseHelper.addPrgressDetail("Press","8","20");
        databaseHelper.addPrgressDetail("Curl","8","20");
        databaseHelper.addPrgressDetail("Calfraise","8","20");
        databaseHelper.addPrgressDetail("Pullup","8","0");
        databaseHelper.addPrgressDetail("SL-Deadlift","8","20");
    }

    public void viewTextSetup()
    {
        tvMovement[0] = (TextView) findViewById(R.id.tvMovement0);
        tvMovement[1] = (TextView) findViewById(R.id.tvMovement1);
        tvMovement[2] = (TextView) findViewById(R.id.tvMovement2);
        tvMovement[3] = (TextView) findViewById(R.id.tvMovement3);
        tvMovement[4] = (TextView) findViewById(R.id.tvMovement4);
        tvMovement[5] = (TextView) findViewById(R.id.tvMovement5);
        tvMovement[6] = (TextView) findViewById(R.id.tvMovement6);
        tvMovement[7] = (TextView) findViewById(R.id.tvMovement7);
        tvMovement[8] = (TextView) findViewById(R.id.tvMovement8);
        tvMovement[9] = (TextView) findViewById(R.id.tvMovement9);
        for(int i=0; i < 10; i++)
        {
            tvMovement[i].setText("");
        }

        tvRep[0] = (TextView) findViewById(R.id.tvRep0);
        tvRep[1] = (TextView) findViewById(R.id.tvRep1);
        tvRep[2] = (TextView) findViewById(R.id.tvRep2);
        tvRep[3] = (TextView) findViewById(R.id.tvRep3);
        tvRep[4] = (TextView) findViewById(R.id.tvRep4);
        tvRep[5] = (TextView) findViewById(R.id.tvRep5);
        tvRep[6] = (TextView) findViewById(R.id.tvRep6);
        tvRep[7] = (TextView) findViewById(R.id.tvRep7);
        tvRep[8] = (TextView) findViewById(R.id.tvRep8);
        tvRep[9] = (TextView) findViewById(R.id.tvRep9);
        for(int i=0; i < 10; i++)
        {
            tvRep[i].setText("");
        }

        tvWeight[0] = (TextView) findViewById(R.id.tvWeight0);
        tvWeight[1] = (TextView) findViewById(R.id.tvWeight1);
        tvWeight[2] = (TextView) findViewById(R.id.tvWeight2);
        tvWeight[3] = (TextView) findViewById(R.id.tvWeight3);
        tvWeight[4] = (TextView) findViewById(R.id.tvWeight4);
        tvWeight[5] = (TextView) findViewById(R.id.tvWeight5);
        tvWeight[6] = (TextView) findViewById(R.id.tvWeight6);
        tvWeight[7] = (TextView) findViewById(R.id.tvWeight7);
        tvWeight[8] = (TextView) findViewById(R.id.tvWeight8);
        tvWeight[9] = (TextView) findViewById(R.id.tvWeight9);
        for(int i=0; i < 10; i++)
        {
            tvWeight[i].setText("");
        }

    }

    public void TextSetup()
    {
        arraySpinner.clear();
        arrayList = databaseHelper.getAllProgressList();
        if(arrayList.size() == 0)
        {
            makeBasicProgress();
            arrayList = databaseHelper.getAllProgressList();
        }
        int row = 0;
        for (int i = 0; i < arrayList.size(); i++){
            tvMovement[row].setText(arrayList.get(i));
            if(i>1){
                arraySpinner.add(arrayList.get(i));
            }
            i++;
            tvRep[row].setText(arrayList.get(i));
            i++;
            tvWeight[row].setText(arrayList.get(i)+"(KG)");
            row++;
        }
    }

    public void setSpinner()
    {
        Spinner spinner = (Spinner) findViewById(R.id.tbSpinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, arraySpinner);
        spinner.setAdapter(adapter);
    }

    public void increaseWeight()
    {
        String reps = "";
        double weight = 0;
        Spinner spinner = (Spinner) findViewById(R.id.tbSpinner);
        String value;
        value = spinner.getSelectedItem().toString();

        arrayList = databaseHelper.getSpecificProgressList(spinner.getSelectedItem().toString());
        reps = arrayList.get(0);
        weight = Double.parseDouble(arrayList.get(1));
        if(weight != 200)
        {
            weight = weight + 0.5;
        }


        databaseHelper.updateUser(value, reps, String.valueOf(weight));
        TextSetup();
    }

    public void decreaseWeight()
    {
        String reps = "";
        double weight = 0;
        Spinner spinner = (Spinner) findViewById(R.id.tbSpinner);
        String value;
        value = spinner.getSelectedItem().toString();

        arrayList = databaseHelper.getSpecificProgressList(spinner.getSelectedItem().toString());
        reps = arrayList.get(0);
        weight = Double.parseDouble(arrayList.get(1));
        if(weight != 0)
        {
            weight = weight - 0.5;
        }

        databaseHelper.updateUser(value, reps, String.valueOf(weight));
        TextSetup();
    }

    public void increaseReps()
    {
        int reps = 0;
        String weight = "";
        Spinner spinner = (Spinner) findViewById(R.id.tbSpinner);
        String value;
        value = spinner.getSelectedItem().toString();

        arrayList = databaseHelper.getSpecificProgressList(spinner.getSelectedItem().toString());
        reps = Integer.parseInt(arrayList.get(0));
        if(reps != 100)
        {
            reps= reps + 1;
        }
        weight = arrayList.get(1);


        databaseHelper.updateUser(value, String.valueOf(reps), weight);
        TextSetup();
    }

    public void decreaseReps()
    {
        int reps = 0;
        String weight = "";
        Spinner spinner = (Spinner) findViewById(R.id.tbSpinner);
        String value;
        value = spinner.getSelectedItem().toString();

        arrayList = databaseHelper.getSpecificProgressList(spinner.getSelectedItem().toString());
        reps = Integer.parseInt(arrayList.get(0));
        if(reps != 0)
        {
            reps= reps - 1;
        }
        weight = arrayList.get(1);


        databaseHelper.updateUser(value, String.valueOf(reps), weight);
        TextSetup();
    }
}