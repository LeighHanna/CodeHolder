package leighhanna.homeandaway;

// Will listen to step alerts
public interface StepListenerInterface {

    public void step(long timeNs);

}

