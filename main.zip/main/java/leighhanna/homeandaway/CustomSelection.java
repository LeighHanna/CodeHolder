package leighhanna.homeandaway;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class CustomSelection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_selection);
        setTitle("Custom Day Select");
    }

    public void  btnA_DayOnClick(View v)
    {
        Intent activityWorkoutSelect = new Intent(this, CustomWorkoutA.class);
        startActivity(activityWorkoutSelect);
    }

    public void  btnB_DayOnClick(View v)
    {
        Intent activityNews = new Intent(this, CustomWorkoutB.class);
        startActivity(activityNews);
    }

    public void  btnC_DayOnClick(View v)
    {
        Intent activityNews = new Intent(this, CustomWorkoutC.class);
        startActivity(activityNews);
    }

    public void  btnD_DayOnClick(View v)
    {
        Intent activityBarbellProgress = new Intent(this, CustomWorkoutD.class);
        startActivity(activityBarbellProgress);
    }

    public void  btnE_DayOnClick(View v)
    {
        Intent activityTest = new Intent(this, CustomWorkoutE.class);
        startActivity(activityTest);
    }
}